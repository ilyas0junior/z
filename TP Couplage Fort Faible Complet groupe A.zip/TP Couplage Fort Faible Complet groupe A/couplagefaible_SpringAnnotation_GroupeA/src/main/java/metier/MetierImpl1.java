package metier;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import dao.IDao;

//@Component("metier")
@Service("metier")
public class MetierImpl1 implements IMetier {

	// couplage faible
	
	
	@Autowired()
	@Qualifier("dao2")
	private  IDao  dao=null;
	
		

	// setter
	public void setDao(IDao dao) {
		this.dao = dao;
	}
	
	// contructeur
//       public Metier(Dao1 dao) {
//		       //super();
//		    this.dao = dao;
//	       }


	public double calculer() {
		double data=dao.getData();
		double res=data*5;
		return res;
	}
	
}
