package dao;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

//@Component("dao2")
@Repository("dao2")
public class DaoImpl2 implements IDao {
	public double getData() {
		System.out.println("Version capture");
		double data=150;
		return data;
	}
}
