package presentation;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Scanner;

import dao.DaoImpl1;
import dao.DaoImpl2;
import dao.IDao;
import metier.IMetier;
import metier.MetierImpl1;

public class Application {

	public static void main(String[] args) {
		
		
		
		
		
		try {
			
			// lecture de fichier config
			Scanner scan=new Scanner(new File("config.txt"));
						
			// lecture de nom de la classe
			String daoClassName=scan.nextLine();
			
			//chargement de la classe Dao en mermoire
			Class cDao = Class.forName(daoClassName);
			// instanciation dynamique
			IDao dao= (IDao) cDao.newInstance()	;
						
			
			
			
			// lire le fichier de configuration
			String metierClassName=scan.nextLine();
			//chargement de la classe Metier en mermoire
			Class cMetier = Class.forName(metierClassName);
			// instanciation dynamique
			IMetier metier= (IMetier)cMetier.newInstance();
			
			// invocation dynamique d'une methode
			Method method=cMetier.getMethod("setDao", IDao.class);
			method.invoke(metier, dao);
						
			 
			// affichage de r�sultat
			System.out.println("le r�sultat est : "+metier.calculer());
			
						
		} catch (Exception e) {
			e.printStackTrace();
		}  
		 
		
		

	}

}
