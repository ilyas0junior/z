package dao;

public class Dao1 {
	
	public double getData() {
		System.out.println("Version base de donn�es");
		double data=100;
		return data;
	}

}
