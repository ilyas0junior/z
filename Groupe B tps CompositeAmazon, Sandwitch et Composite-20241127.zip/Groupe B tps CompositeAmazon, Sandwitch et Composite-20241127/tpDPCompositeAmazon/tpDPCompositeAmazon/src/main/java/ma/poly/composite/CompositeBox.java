package ma.poly.composite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CompositeBox implements Box {
    private List<Box> children;

    public CompositeBox(Box... boxes) {
        this.children = new ArrayList<>();
        children.addAll(Arrays.asList(boxes));
    }

    @Override
    public double calculatePrice() {
        return children.stream().mapToDouble(Box::calculatePrice).sum() ;
    }
}
