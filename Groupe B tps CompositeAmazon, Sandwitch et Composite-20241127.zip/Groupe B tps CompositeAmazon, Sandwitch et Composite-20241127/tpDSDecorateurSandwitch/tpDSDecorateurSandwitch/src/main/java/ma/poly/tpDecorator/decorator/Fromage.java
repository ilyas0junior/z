package ma.poly.tpDecorator.decorator;

import ma.poly.tpDecorator.Sandwitch;

public class Fromage extends SandwitchDecorator{
    public Fromage(Sandwitch sandwitch) {
        super(sandwitch);
    }

    @Override
    public double getCout() {
        return sandwitch.getCout()  +10;
    }

    public String getDescription(){

        return sandwitch.getDescription()+" Au Fromage";
    }
}
