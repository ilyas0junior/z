package ma.poly.tpDecorator.decorator;

import ma.poly.tpDecorator.Sandwitch;

public class Poulet extends SandwitchDecorator{
    public Poulet(Sandwitch sandwitch) {
        super(sandwitch);
    }

    @Override
    public double getCout() {
        return sandwitch.getCout()  +25;
    }

    public String getDescription(){
        return sandwitch.getDescription()+" Au Poulet";
    }
}
