package ma.poly.tpDecorator;

public abstract class Sandwitch {
    protected  String description;

    public String getDescription() {
        return description;
    }

    public abstract double getCout();
}
