package ma.poly.tpDecorator;

public class SandwitchBasic extends Sandwitch {

    public SandwitchBasic() {
        this.description="Sandwitch Basic ";
    }

    @Override
    public double getCout() {
        return 20;
    }

}
