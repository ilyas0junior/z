package ma.poly;

import ma.poly.tpDecorator.Sandwitch;
import ma.poly.tpDecorator.SandwitchBasic;
import ma.poly.tpDecorator.decorator.Fritte;
import ma.poly.tpDecorator.decorator.Fromage;
import ma.poly.tpDecorator.decorator.Viande;

public class Client {
    public static void main(String[] args) {
        // ceation d'un objet sandwitch
        Sandwitch sandwitch;
        System.out.println("======= Sandwitch Basic =======");
        sandwitch=new SandwitchBasic();
        System.out.println("Description : "+sandwitch.getDescription());
        System.out.println("Cout : "+ sandwitch.getCout()+" Dh");

        System.out.println("======= Sandwitch Basic au Viande =======");
        sandwitch=new Viande(new SandwitchBasic()) ;
        System.out.println("Description : "+sandwitch.getDescription());
        System.out.println("Cout : "+ sandwitch.getCout()+" Dh");

        System.out.println("======= Sandwitch Basic au Viande au fritte et au Fromage =======");
        sandwitch= new Fromage(new Fritte(new Viande(new SandwitchBasic()))) ;
        System.out.println("Description : "+sandwitch.getDescription());
        System.out.println("Cout : "+ sandwitch.getCout()+" Dh");

    }
}